package DesignPattern.BehavioralPatterns.TemplateDataExporter;

public record MetaData(String filename, Format format) {
}
